# Universe Platform Template (Static)

這是一個可直接部署到 GitHub Pages 的靜態平台模板（首頁 / 線上抽牌 / 牌庫 / 單張牌頁）。

## 檔案
- index.html
- draw.html
- deck.html
- card.html
- styles.css
- data.js
- app.js

## 使用
1. 直接開啟 index.html
2. 或用 VS Code + Live Server
3. 上線：GitHub Pages（main / root）
